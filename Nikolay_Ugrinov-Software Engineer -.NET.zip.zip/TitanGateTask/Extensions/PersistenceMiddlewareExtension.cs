﻿using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TitanGateTask.Persistence;
using TitanGateTask.Persistence.Static;

namespace TitanGateTask.Extensions
{
    public static class PersistenceMiddlewareExtension
    {
        private static readonly string persistence = "Persistence";
        public static void ConfigureAppPersistence(this IApplicationBuilder app, IConfiguration configuration)
        {
            if (configuration[persistence] == "database")
            {
                using (var scope = app.ApplicationServices.CreateScope())
                {
                    using (var context = scope.ServiceProvider.GetService<TitanGateDbContext>())
                    {
                        context.Database.Migrate();
                    }
                }
            }
        }

        public static IServiceCollection AddServicePersistence(this IServiceCollection services, IConfiguration configuration)
        {
            if(configuration[persistence] == "database")
            {
                services.AddInfrastructure(configuration);
            }

            if (configuration[persistence] == "static")
            {
                services.AddStaticInfrastructure(configuration);
            }

            return services;
        }
    }
}
