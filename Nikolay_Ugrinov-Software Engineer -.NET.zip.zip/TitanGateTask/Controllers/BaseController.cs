﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.RequestFeatures;

namespace TitanGateTask.Controllers
{
    public abstract class BaseController : ControllerBase
    {
        protected void SetPaginationHeader<T>(PagedList<T> list)
        {
            var paginationMetadata = new
            {
                totalCount = list.MetaData.TotalCount,
                pageSize = list.MetaData.PageSize,
                currentPage = list.MetaData.CurrentPage,
                totalPages = list.MetaData.TotalPages
            };

            Response.Headers.Add("X-Pagination",
                JsonSerializer.Serialize(paginationMetadata));
        }

        protected ActionResult HandleResult<T>(ServerResponse<ServerResponseTypeEnum, T> result)
        {
            if(result.Response == ServerResponseTypeEnum.Deleted)
            {
                return BadRequest(result.Message);
            }

            if (result.Response == ServerResponseTypeEnum.NotFound)
            {
                return NotFound(result.Message);
            }

            if (result.Response == ServerResponseTypeEnum.Created)
            {
                return Created(Uri.UriSchemeHttps, result.Data.ToString());
            }

            if (result.Response == ServerResponseTypeEnum.NoContent)
            {
                return NoContent();
            }

            return Ok(result.Data);
        }
    }
}