﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TitanGateTask.Application.Contracts.WebsiteCredentials;
using TitanGateTask.Application.Contracts.Websites.Commands;
using TitanGateTask.Application.Models.DataTransferObjects.WebsiteCredentials;
using TitanGateTask.Filters;

namespace TitanGateTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WebsiteCredentialsController : BaseController
    {
        private IUpdateWebsiteCredentialsCommand updateWebsiteCredentialsCommand;

        public WebsiteCredentialsController(IUpdateWebsiteCredentialsCommand updateWebsiteCredentialsCommand)
        {
            this.updateWebsiteCredentialsCommand = updateWebsiteCredentialsCommand;
        }

        /// <summary>
        /// Update fully an website credentials
        /// </summary>
        /// <param name="id">Id of the website</param>
        /// <returns>Status Code 204 if updated, 400 if deleted, 404 if not found</returns>
        [HttpPut("{id}")]
        [ValidateUpdateModel]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Update(int id, [FromBody]WebsiteCredentialsUpdateDto dto)
        {
            var response = await updateWebsiteCredentialsCommand.Handle(id, dto);

            return HandleResult(response);
        }
    }
}