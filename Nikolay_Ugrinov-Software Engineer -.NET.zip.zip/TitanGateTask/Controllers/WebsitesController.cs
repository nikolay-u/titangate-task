﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using TitanGateTask.Application.Contracts.Websites.Queries;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Implementations.Websites.Queries.GetWebsiteListQuery;
using TitanGateTask.Application.RequestFeatures;
using System.Web;
using TitanGateTask.Application.Contracts.Websites.Commands;
using TitanGateTask.Filters;

namespace TitanGateTask.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class WebsitesController : BaseController
    {
        private IGetWebsiteListQuery websiteListQuery;

        private IGetSingleWebsiteQuery websiteSingleQuery;

        private IAddWebsiteCommand addWebsiteCommand;

        private IUpdateWebsiteCommand updateWebsiteCommand;

        private IPatchWebsiteCommand patchWebsiteCommand;

        private IDeleteWebsiteCommand deleteWebsiteCommand;

        public WebsitesController(
            IGetWebsiteListQuery websiteListQuery,
            IGetSingleWebsiteQuery websiteSingleQuery,
            IAddWebsiteCommand addWebsiteCommand,
            IUpdateWebsiteCommand updateWebsiteCommand,
            IPatchWebsiteCommand patchWebsiteCommand,
            IDeleteWebsiteCommand deleteWebsiteCommand
            )
        {
            this.websiteListQuery = websiteListQuery;
            this.websiteSingleQuery = websiteSingleQuery;
            this.addWebsiteCommand = addWebsiteCommand;
            this.updateWebsiteCommand = updateWebsiteCommand;
            this.patchWebsiteCommand = patchWebsiteCommand;
            this.deleteWebsiteCommand = deleteWebsiteCommand;
        }

        /// <summary>
        /// Gets a single website by a specified id
        /// </summary>
        /// <returns>Status Code 200 if found, 400 if deleted, 404 if not found</returns>
        [HttpGet("{id}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> GetSingle(int id)
        {
            var response = await websiteSingleQuery.Handle(id);

            return HandleResult(response);
        }

        /// <summary>
        /// Gets the list of all websites
        /// </summary>
        /// <returns>The website list</returns>
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult> GetAll([FromQuery]WebsiteRequestParameters parameters)
        {
            var response = await websiteListQuery.Handle(parameters);
            SetPaginationHeader(response);

            return Ok(response);
        }

        /// <summary>
        /// Create a new website
        /// </summary>
        /// <returns>Id of the new website</returns>
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<ActionResult> Create([FromBody]WebsiteCreateDto dto)
        {
            var response = await addWebsiteCommand.Handle(dto);

            return HandleResult(response);
        }

        /// <summary>
        /// Update fully an existing website
        /// </summary>
        /// <returns>Status Code 204 if updated, 400 if deleted, 404 if not found</returns>
        [HttpPut("{id}")]
        [ValidateUpdateModel]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Update(int id, [FromBody]WebsiteUpdateDto dto)
        {
            var response = await updateWebsiteCommand.Handle(id, dto);

            return HandleResult(response);
        }

        /// <summary>
        /// Update partially an existing website
        /// </summary>
        /// <returns>Status Code 204 if updated, 400 if deleted, 404 if not found</returns>
        [HttpPatch("{id}")]
        [ValidateUpdateModel]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Patch(int id, [FromBody] JsonPatchDocument<WebsiteUpdateDto> dto)
        {
            var response = await patchWebsiteCommand.Handle(id, dto);

            return HandleResult(response);
        }

        /// <summary>
        /// Delete an existing website
        /// </summary>
        /// <returns>Status Code 204 if deleted successfully, 400 if already deleted, 404 if not found</returns>
        [HttpDelete("{id}")]
        [ValidateUpdateModel]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public async Task<ActionResult> Delete(int id)
        {
            var response = await deleteWebsiteCommand.Handle(id);

            return HandleResult(response);
        }
    }
}