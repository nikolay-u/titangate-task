﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Tests.Common;
using Xunit;
using TitanGateTask.Application.Implementations.Websites.Commands.AddWebsiteCommand;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Enums;
using Moq;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Tests.Implementations.Commands.AddWebsiteCommand
{
    public class AddWebsiteCommandFixture : CommandTestBase
    {
        [Fact]
        public async Task Add_Website_Calls_Repositories()
        {
            var query = new Application.Implementations.Websites.Commands.AddWebsiteCommand.AddWebsiteCommand(websiteRepository.Object, credentialsRepository.Object, mapper);
            var website = new WebsiteCreateDto { Name = "Test", Url= "http://test.com" };
            var result = await query.Handle(website);

            Assert.NotNull(result);
            Assert.Equal(ServerResponseTypeEnum.Created, result.Response);
            websiteRepository.Verify(mock => mock.AddAsync(It.IsAny<Website>()), Times.Once);
            credentialsRepository.Verify(mock => mock.AddAsync(It.IsAny<WebsiteCredentials>()), Times.Once);
        }
    }
}
