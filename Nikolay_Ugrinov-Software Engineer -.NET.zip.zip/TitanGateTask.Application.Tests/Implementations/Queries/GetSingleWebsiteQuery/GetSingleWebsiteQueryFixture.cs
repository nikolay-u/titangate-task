﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Implementations.Websites.Queries.GetSingleWebsiteQuery;
using TitanGateTask.Application.Tests.Common;
using Xunit;

namespace TitanGateTask.Application.Tests.Implementations.Queries
{
    public class GetSingleWebsiteQueryFixture : QueryTestBase
    {
        [Fact]
        public async Task Existing_Website_Is_Found()
        {
            var query = new GetSingleWebsiteQuery(websiteRepository.Object, mapper);

            var result = await query.Handle(1);

            Assert.NotNull(result);
            Assert.Equal(ServerResponseTypeEnum.OK, result.Response);
            Assert.NotNull(result.Data);
            Assert.Equal(1, result.Data.Id);
            Assert.Equal("Test", result.Data.Name);
        }

        [Fact]
        public async Task Not_Existing_Website_Is_Not_Found()
        {
            var query = new GetSingleWebsiteQuery(websiteRepository.Object, mapper);

            var result = await query.Handle(99);

            Assert.NotNull(result);
            Assert.Equal(ServerResponseTypeEnum.NotFound, result.Response);
            Assert.Equal("Website not found", result.Message);
            Assert.Null(result.Data);
        }

        [Fact]
        public async Task Deleted_Website_Is_Not_Found()
        {
            var query = new GetSingleWebsiteQuery(websiteRepository.Object, mapper);

            var result = await query.Handle(2);

            Assert.NotNull(result);
            Assert.Equal(ServerResponseTypeEnum.Deleted, result.Response);
            Assert.Equal("Website has been deleted", result.Message);
            Assert.Null(result.Data);
        }
    }
}
