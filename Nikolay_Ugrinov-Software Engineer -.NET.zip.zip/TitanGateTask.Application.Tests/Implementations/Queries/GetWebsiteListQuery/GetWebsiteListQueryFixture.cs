﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Moq;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Implementations.Websites.Queries.GetSingleWebsiteQuery;
using TitanGateTask.Application.Implementations.Websites.Queries.GetWebsiteListQuery;
using TitanGateTask.Application.RequestFeatures;
using TitanGateTask.Application.Tests.Common;
using Xunit;

namespace TitanGateTask.Application.Tests.Implementations.Queries
{
    public class GetWebsiteListQueryFixture : QueryTestBase
    {
        [Fact]
        public async Task Default_Parameters_Return_Full_List()
        {
            var query = new GetWebsiteListQuery(websiteRepository.Object, mapper);
            var parameters = new WebsiteRequestParameters();

            var result = await query.Handle(parameters);

            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Equal(1, result.MetaData.CurrentPage);
            Assert.True(result.MetaData.HasNext);
            Assert.False(result.MetaData.HasPrevious);
            Assert.Equal(7, result.MetaData.TotalCount);
            Assert.Equal(4, result.MetaData.TotalPages);
        }
    }
}
