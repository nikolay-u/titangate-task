﻿using AutoMapper;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Mappings;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Tests.Common
{
    public class CommandTestBase
    {
        protected Mock<IWebsiteRepository> websiteRepository;
        protected Mock<IRepositoryBase<WebsiteCredentials>> credentialsRepository;
        protected IMapper mapper;

        public CommandTestBase()
        {
            websiteRepository = new Mock<IWebsiteRepository>();
            credentialsRepository = new Mock<IRepositoryBase<WebsiteCredentials>>();
            websiteRepository.Setup(x => x.AddAsync(It.IsAny<Website>())).Returns(Task.FromResult(new Website { Id = 1 , Name="Added" }));
            credentialsRepository.Setup(x => x.AddAsync(It.IsAny<WebsiteCredentials>())).Returns(Task.FromResult(new WebsiteCredentials { Id = 1 }));

            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new WebsiteCredentialsProfile());
                mc.AddProfile(new WebsiteProfile());
            });

            mapper = mappingConfig.CreateMapper();
        }
    }
}
