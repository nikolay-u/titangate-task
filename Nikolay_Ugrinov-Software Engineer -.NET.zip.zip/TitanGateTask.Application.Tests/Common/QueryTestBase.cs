﻿using AutoMapper;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Mappings;
using TitanGateTask.Application.RequestFeatures;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Tests.Common
{
    public class QueryTestBase
    {
        protected Mock<IWebsiteRepository> websiteRepository;
        protected Mock<IRepositoryBase<WebsiteCredentials>> credentialsRepository;
        protected IMapper mapper;

        private List<Website> list = new List<Website>
        {
            new Website { Id = 1, Name = "Test" },
            new Website { Id = 2, Name = "GHJK" },
            new Website { Id = 3, Name = "ABCD" },
            new Website { Id = 4, Name = "ZXCV" },
            new Website { Id = 5, Name = "QWER" },
            new Website { Id = 6, Name = "VBNM" },
            new Website { Id = 7, Name = "TYUI" }
        };

        public QueryTestBase()
        {
            websiteRepository = new Mock<IWebsiteRepository>();
            credentialsRepository = new Mock<IRepositoryBase<WebsiteCredentials>>();

            websiteRepository.Setup(x => x.GetByIdAsync(1)).Returns(Task.FromResult(new Website { Id = 1, Name = "Test" }));
            websiteRepository.Setup(x => x.GetByIdAsync(2)).Returns(Task.FromResult(new Website { Id = 2, Name = "Deleted", IsDeleted = true }));

            websiteRepository.Setup(x=> x.PagedList(It.IsAny<WebsiteRequestParameters>(), false)).Returns(Task.FromResult(PagedList<Website>.ToPagedList(list, 1, 2)));
            
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new WebsiteCredentialsProfile());
                mc.AddProfile(new WebsiteProfile());
            });

            mapper = mappingConfig.CreateMapper();
        }
    }
}
