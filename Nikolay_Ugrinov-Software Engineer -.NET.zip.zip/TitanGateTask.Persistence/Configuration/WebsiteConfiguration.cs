﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TitanGateTask.Domain;

namespace TitanGateTask.Persistence.Configuration
{
    public class WebsiteConfiguration : IEntityTypeConfiguration<Website>
    {
        public void Configure(EntityTypeBuilder<Website> builder)
        {
            builder.HasData
            (
                new Website
                {
                    Id = 1,
                    Name = "Google",
                    Url = "http://google.com",
                    HomepageSnapshot = "snapshotsample.jpg",
                    CategoryId = 1,
                    WebsiteCredentialsId = 1,
                    IsDeleted = false
                },
                new Website
                {
                    Id = 2,
                    Name = "Yahoo",
                    Url = "http://yahoo.com",
                    HomepageSnapshot = "snapshotsample.jpg",
                    CategoryId = 1,
                    WebsiteCredentialsId = 2,
                    IsDeleted = false
                },
                new Website
                {
                    Id = 3,
                    Name = "Youtube",
                    Url = "http://youtube.com",
                    HomepageSnapshot = "snapshotsample.jpg",
                    CategoryId = 1,
                    WebsiteCredentialsId = 3,
                    IsDeleted = false
                }

            );
        }
    }
}
