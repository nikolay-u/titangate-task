﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TitanGateTask.Domain;

namespace TitanGateTask.Persistence.Configuration
{
    public class WebsiteCredentialsConfiguration : IEntityTypeConfiguration<WebsiteCredentials>
    {
        public void Configure(EntityTypeBuilder<WebsiteCredentials> builder)
        {
            builder.HasData
            (
                new WebsiteCredentials
                {
                    Id = 1,
                    Email = "ivan@titangate.com",
                    Password = "P@ssw0rd"
                },
                new WebsiteCredentials
                {
                    Id = 2,
                    Email = "peter@titangate.com",
                    Password = "P@ssw0rd"
                }, 
                new WebsiteCredentials
                {
                    Id = 3,
                    Email = "ivan@titangate.com",
                    Password = "P@ssw0rd"
                }
            );
        }
    }
}
