﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TitanGateTask.Domain;

namespace TitanGateTask.Persistence.Configuration
{
    public class CategoryConfiguration : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> builder)
        {
            builder.HasData
            (
                new Category
                {
                    Id = 1,
                    Name = "Search"
                },
                new Category
                {
                    Id = 2,
                    Name = "Social Media"
                },
                new Category
                {
                    Id = 3,
                    Name = "Gaming"
                },
                new Category
                {
                    Id = 4,
                    Name = "News"
                }
            );
        }
    }
}
