﻿using Microsoft.EntityFrameworkCore;
using TitanGateTask.Domain;

namespace TitanGateTask.Infrastructure.Contracts
{
    public interface ITitanGateDbContext
    {
        DbSet<Website> Websites { get; set; }

        DbSet<WebsiteCredentials> WebsiteCredentials { get; set; }

        DbSet<Category> Categories { get; set; }
    }
}
