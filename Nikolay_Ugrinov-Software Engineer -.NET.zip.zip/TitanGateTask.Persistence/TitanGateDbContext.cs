﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.EntityFrameworkCore;
using TitanGateTask.Domain;
using TitanGateTask.Infrastructure.Contracts;
using TitanGateTask.Persistence.Configuration;
using TitanGateTask.Persistence.Logging;

namespace TitanGateTask.Persistence
{
    public class TitanGateDbContext : DbContext, ITitanGateDbContext
    {
        public TitanGateDbContext(DbContextOptions options)
        : base(options)
        {
        }

        public DbSet<Website> Websites { get; set; }

        public DbSet<WebsiteCredentials> WebsiteCredentials { get; set; }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Log> Logs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            
            modelBuilder.ApplyConfiguration(new CategoryConfiguration());
            modelBuilder.ApplyConfiguration(new WebsiteCredentialsConfiguration());
            modelBuilder.ApplyConfiguration(new WebsiteConfiguration());
        }

    }
}
