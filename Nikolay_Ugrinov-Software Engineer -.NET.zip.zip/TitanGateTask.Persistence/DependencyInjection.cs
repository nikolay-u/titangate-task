﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Microsoft.EntityFrameworkCore;
using TitanGateTask.Infrastructure.Contracts;
using TitanGateTask.Persistence.Logging;
using TitanGateTask.Persistence.Implementations.Repositories;
using TitanGateTask.Application.Contracts.Repositories;

namespace TitanGateTask.Persistence
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("Database");
            services.AddDbContext<TitanGateDbContext>(options => options.UseSqlServer(connectionString));
            NLog.GlobalDiagnosticsContext.Set("TitanGateLogging", connectionString);

            services.AddScoped(typeof(IRepositoryBase<>), typeof(RepositoryBase<>));
            services.AddScoped<IWebsiteRepository, WebsiteRepository>();
            services.AddScoped<ILoggerManager, LoggerManager>();
            services.AddScoped<ITitanGateDbContext>(provider => provider.GetService<TitanGateDbContext>());
            
            return services;
        }
    }
}
