﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Text;
using TitanGateTask.Application.Implementations.Websites.Queries.GetWebsiteListQuery;
using TitanGateTask.Application.RequestFeatures;
using TitanGateTask.Domain;

namespace TitanGateTask.Persistence.Extensions
{
    public static class WebsiteRepositoryExtensions
    {
        public static IQueryable<Website> Search(this IQueryable<Website> websites, string searchTerm)
        {
            if (string.IsNullOrWhiteSpace(searchTerm))
            {
                return websites;
            }

            var lowerCaseTerm = searchTerm.Trim().ToLower();

            return websites.Where(website => website.Name.ToLower().Contains(lowerCaseTerm));
        }

        public static IQueryable<Website> Filter(this IQueryable<Website> websites, WebsiteRequestParameters parameters)
        {
            if (parameters.CategoryId.HasValue)
            {
                websites = websites.Where(website => website.CategoryId == parameters.CategoryId.Value);
            }

            websites = websites.Where(website => !website.IsDeleted);

            return websites;
        }

        public static IQueryable<Website> Sort(this IQueryable<Website> websites, string orderByQueryString)
        {
            if (string.IsNullOrWhiteSpace(orderByQueryString))
            {
                return websites.OrderBy(website => website.Name);
            }

            try
            {
                websites = websites.OrderBy(orderByQueryString);
            }
            catch
            {
                websites = websites.OrderBy(website => website.Name);
            }

            return websites;
        }
    }
}
