﻿using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.RequestFeatures;
using TitanGateTask.Domain;
using TitanGateTask.Persistence.Extensions;

namespace TitanGateTask.Persistence.Implementations.Repositories
{
    public class WebsiteRepository : RepositoryBase<Website>, IWebsiteRepository
    {
        public WebsiteRepository(TitanGateDbContext dbContext) : base(dbContext)
        {
        }

        public async Task<PagedList<Website>> PagedList(WebsiteRequestParameters parameters, bool trackChanges)
        {
            var list = ListAllAsync()
                                     .Search(parameters.SearchTerm)
                                     .Filter(parameters)
                                     .Sort(parameters.OrderBy);

            if (!trackChanges)
            {
                list = list.AsNoTracking();
            }

            var fullList = list.Include(website => website.Category).Include(website => website.WebsiteCredentials);
            var pagedList = PagedList<Website>.ToPagedList(fullList, parameters.PageNumber, parameters.PageSize);
            return pagedList;
        }

        public override async Task<Website> GetByIdAsync(int id)
        {
            return await dbContext.Websites.Include(website => website.Category).Include(website => website.WebsiteCredentials).AsNoTracking().FirstOrDefaultAsync(website=>website.Id == id);
        }
    }
}
