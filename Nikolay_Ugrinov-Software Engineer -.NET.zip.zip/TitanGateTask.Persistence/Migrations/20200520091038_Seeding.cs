﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace TitanGateTask.Persistence.Migrations
{
    public partial class Seeding : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<string>(
                name: "HomepageSnapshot",
                table: "Websites",
                maxLength: 200,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(200)",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.UpdateData(
                table: "Websites",
                keyColumn: "WebsiteId",
                keyValue: 1,
                column: "HomepageSnapshot",
                value: "snapshotsample.jpg");

            migrationBuilder.InsertData(
                table: "Websites",
                columns: new[] { "WebsiteId", "CategoryId", "HomepageSnapshot", "IsDeleted", "Name", "Url", "WebsiteCredentialsId" },
                values: new object[] { 3, 1, "snapshotsample.jpg", false, "Youtube", "http://youtube.com", 3 });

            migrationBuilder.InsertData(
                table: "Websites",
                columns: new[] { "WebsiteId", "CategoryId", "HomepageSnapshot", "IsDeleted", "Name", "Url", "WebsiteCredentialsId" },
                values: new object[] { 2, 1, "snapshotsample.jpg", false, "Yahoo", "http://yahoo.com", 2 });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Websites",
                keyColumn: "WebsiteId",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Websites",
                keyColumn: "WebsiteId",
                keyValue: 3);

            migrationBuilder.AlterColumn<string>(
                name: "HomepageSnapshot",
                table: "Websites",
                type: "nvarchar(200)",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldMaxLength: 200);

            migrationBuilder.UpdateData(
                table: "Websites",
                keyColumn: "WebsiteId",
                keyValue: 1,
                column: "HomepageSnapshot",
                value: "");
        }
    }
}
