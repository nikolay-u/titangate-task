﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace TitanGateTask.Persistence.Migrations
{
    public partial class InitialSetup : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Categories",
                columns: table => new
                {
                    CategoryId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Categories", x => x.CategoryId);
                });

            migrationBuilder.CreateTable(
                name: "Logs",
                columns: table => new
                {
                    LogId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Level = table.Column<string>(nullable: true),
                    Message = table.Column<string>(nullable: true),
                    Date = table.Column<DateTime>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Logs", x => x.LogId);
                });

            migrationBuilder.CreateTable(
                name: "WebsiteCredentials",
                columns: table => new
                {
                    WebsiteCredentialsId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(maxLength: 100, nullable: false),
                    Password = table.Column<string>(maxLength: 40, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_WebsiteCredentials", x => x.WebsiteCredentialsId);
                });

            migrationBuilder.CreateTable(
                name: "Websites",
                columns: table => new
                {
                    WebsiteId = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(maxLength: 100, nullable: false),
                    Url = table.Column<string>(maxLength: 200, nullable: false),
                    HomepageSnapshot = table.Column<string>(maxLength: 200, nullable: true),
                    CategoryId = table.Column<int>(nullable: false),
                    WebsiteCredentialsId = table.Column<int>(nullable: false),
                    IsDeleted = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Websites", x => x.WebsiteId);
                    table.ForeignKey(
                        name: "FK_Websites_Categories_CategoryId",
                        column: x => x.CategoryId,
                        principalTable: "Categories",
                        principalColumn: "CategoryId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Websites_WebsiteCredentials_WebsiteCredentialsId",
                        column: x => x.WebsiteCredentialsId,
                        principalTable: "WebsiteCredentials",
                        principalColumn: "WebsiteCredentialsId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Categories",
                columns: new[] { "CategoryId", "Name" },
                values: new object[,]
                {
                    { 1, "Search" },
                    { 2, "Social Media" },
                    { 3, "Gaming" },
                    { 4, "News" }
                });

            migrationBuilder.InsertData(
                table: "WebsiteCredentials",
                columns: new[] { "WebsiteCredentialsId", "Email", "Password" },
                values: new object[,]
                {
                    { 1, "ivan@titangate.com", "P@ssw0rd" },
                    { 2, "peter@titangate.com", "P@ssw0rd" },
                    { 3, "ivan@titangate.com", "P@ssw0rd" }
                });

            migrationBuilder.InsertData(
                table: "Websites",
                columns: new[] { "WebsiteId", "CategoryId", "HomepageSnapshot", "IsDeleted", "Name", "Url", "WebsiteCredentialsId" },
                values: new object[] { 1, 1, "", false, "Google", "http://google.com", 1 });

            migrationBuilder.CreateIndex(
                name: "IX_Websites_CategoryId",
                table: "Websites",
                column: "CategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_Websites_WebsiteCredentialsId",
                table: "Websites",
                column: "WebsiteCredentialsId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Logs");

            migrationBuilder.DropTable(
                name: "Websites");

            migrationBuilder.DropTable(
                name: "Categories");

            migrationBuilder.DropTable(
                name: "WebsiteCredentials");
        }
    }
}
