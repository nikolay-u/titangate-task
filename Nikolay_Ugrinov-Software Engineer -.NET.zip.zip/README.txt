TitanGate Task By Nikolay Ugrinov
Started 15.05.2020 (afternoon) - completed 20.05.2020

1. Steps to create the database
- Make sure the connection string is OK for your environment (LocalDb). Run the application, the database is going to be created automatically

2. Steps to prepare the source code to build/run properly
- Rebuild the application. All dependencies should be added.

3. Assumptions and feedback
- I've added the possibility to change the database to test the requirement that changing the database will not require refactoring of the controllers.
Change the appsetting "Persistence" to "static" to test a scenario with an alternative datasource. Please note this is for purely testing/demo purposes only and only get methods are implemented.
The application is expected to work fully with the "database" setting.
- I decided to separate updating of website and website credentials. I suppose in "real-world" scenario not all updates of the website will require update of passwords and vice-versa.
- I assume this is a demo task, so no additional password features, like salting, etc. are implemented.
- I assume in a real world scenario data shaping and HATEOAS support are going to be suitable, but it would go outside of the scope of the task. I would like to discuss these extensions during the interview. It would be a nice requirement.
- Pagination metadata is passed with and extension header parameter.
- I've included a Postman collection for easier testing
- I've added Unit tests for the Application service layer only. I would like to discuss Unit testing during the interview.
- I've added NLog as an external dependency for logging purposes.
- I haven't added otherwise suitable dependencies, such as Mediatr, etc., since the requirement was to use as few thrid-party libraries as possible.
