﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Models.DataTransferObjects.WebsiteCredentials;

namespace TitanGateTask.Application.Contracts.WebsiteCredentials
{
    public interface IUpdateWebsiteCredentialsCommand
    {
        Task<ServerResponse<ServerResponseTypeEnum, object>> Handle(int id, WebsiteCredentialsUpdateDto dto);
    }
}
