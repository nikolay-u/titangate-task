﻿using System.Threading.Tasks;
using TitanGateTask.Application.RequestFeatures;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Contracts.Repositories
{
    public interface IWebsiteRepository: IRepositoryBase<Website>
    {
        Task<PagedList<Website>> PagedList(WebsiteRequestParameters parameters, bool trackChanges);
    }
}
