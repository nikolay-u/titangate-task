﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Enums;

namespace TitanGateTask.Application.Contracts.Websites.Commands
{
    public interface IDeleteWebsiteCommand
    {
        Task<ServerResponse<ServerResponseTypeEnum, object>> Handle(int id);
    }
}
