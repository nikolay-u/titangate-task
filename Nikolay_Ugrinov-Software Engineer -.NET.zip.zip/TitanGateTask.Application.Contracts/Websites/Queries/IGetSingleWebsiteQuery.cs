﻿using System;
using System.Threading.Tasks;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Enums;

namespace TitanGateTask.Application.Contracts.Websites.Queries
{
    public interface IGetSingleWebsiteQuery
    {
        Task<ServerResponse<ServerResponseTypeEnum, WebsiteSingleDto>> Handle(int id);
    }
}
