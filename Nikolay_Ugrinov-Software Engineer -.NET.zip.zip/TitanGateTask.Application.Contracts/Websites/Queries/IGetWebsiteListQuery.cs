﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.RequestFeatures;

namespace TitanGateTask.Application.Contracts.Websites.Queries
{
    public interface IGetWebsiteListQuery
    {
        Task<PagedList<WebsiteListItemDto>> Handle(WebsiteRequestParameters parameters);
    }
}
