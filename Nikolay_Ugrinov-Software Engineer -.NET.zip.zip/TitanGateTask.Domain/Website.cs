﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using TitanGateTask.Domain.Contracts;

namespace TitanGateTask.Domain
{
    public class Website : IEntity
    {
        [Column("WebsiteId")] 
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Website name is required")] 
        [MaxLength(100, ErrorMessage = "Maximum length for the Website name is 100 characters")] 
        public string Name { get; set; }

        [Required(ErrorMessage = "Url is required")]
        [MaxLength(200, ErrorMessage = "Maximum length for the Url is 200 characters")]
        public string Url { get; set; }

        [Required(ErrorMessage = "HomepageSnapshot is required")]
        [MaxLength(200, ErrorMessage = "Maximum length for the Homepage Snapshot is 200 characters")]
        public string HomepageSnapshot { get; set; }

        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public Category Category { get; set; }

        public int WebsiteCredentialsId { get; set; }

        [ForeignKey("WebsiteCredentialsId")]
        public WebsiteCredentials WebsiteCredentials { get; set; }

        public bool IsDeleted { get; set; }
    }
}
