﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TitanGateTask.Domain
{
    public class Category
    {
        [Column("CategoryId")]
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Category name is required")]
        [MaxLength(50, ErrorMessage = "Maximum length for the Category name is 50 characters")]
        public string Name { get; set; }
    }
}
