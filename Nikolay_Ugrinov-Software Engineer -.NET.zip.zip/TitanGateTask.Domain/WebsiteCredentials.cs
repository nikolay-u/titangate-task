﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace TitanGateTask.Domain
{
    public class WebsiteCredentials
    {
        [Column("WebsiteCredentialsId")]
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [MaxLength(100, ErrorMessage = "Maximum length for the Email is 100 characters")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [MinLength(5, ErrorMessage = "Minimum length for the Password is 5 characters")]
        [MaxLength(40, ErrorMessage = "Maximum length for the Password is 40 characters")]
        public string Password { get; set; }
    }
}
