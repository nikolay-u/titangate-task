﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Contracts.WebsiteCredentials;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Models.DataTransferObjects.WebsiteCredentials;
using TitanGateTask.Application.Validation;
using TitanGateTask.Domain;
namespace TitanGateTask.Application.Implementations.WebsiteCredentials.Commands.UpdateWebsiteCredentialsCommand
{
    public class UpdateWebsiteCredentialsCommand : IUpdateWebsiteCredentialsCommand
    {
        private IWebsiteRepository repository;
        private IRepositoryBase<Domain.WebsiteCredentials> credentialsRepository;
        private IMapper mapper;
        private IEnumerable<IValidationStrategy> validations = new List<IValidationStrategy>
        {
            new NotFoundValidation("Website not found"),
            new DeletedValidation("Can't update a deleted website")
        };

        public UpdateWebsiteCredentialsCommand(
            IWebsiteRepository repository,
            IRepositoryBase<Domain.WebsiteCredentials> credentialsRepository,
            IMapper mapper)
        {
            this.repository = repository;
            this.credentialsRepository = credentialsRepository;
            this.mapper = mapper;
        }

        public async Task<ServerResponse<ServerResponseTypeEnum, object>> Handle(int id, WebsiteCredentialsUpdateDto dto)
        {
            var website = await repository.GetByIdAsync(id);
            foreach (var validation in validations)
            {
                var validationResult = validation.Validate(website);
                if (validationResult != null)
                {
                    return new ServerResponse<ServerResponseTypeEnum, object>(validationResult.Response, null, validationResult.Message);
                }
            }

            var websiteCredentials = website.WebsiteCredentials;
            websiteCredentials.Password = dto.NewPassword;
            websiteCredentials.Email = dto.Email;
            await credentialsRepository.UpdateAsync(websiteCredentials);

            return new ServerResponse<ServerResponseTypeEnum, object>(ServerResponseTypeEnum.NoContent, null);
        }
    }
}
