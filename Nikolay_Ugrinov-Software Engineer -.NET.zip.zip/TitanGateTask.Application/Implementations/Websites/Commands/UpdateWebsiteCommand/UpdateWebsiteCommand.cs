﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Contracts.Websites.Commands;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Validation;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Implementations.Websites.Commands.UpdateWebsiteCommand
{
    public class UpdateWebsiteCommand : IUpdateWebsiteCommand
    {
        private IWebsiteRepository repository;
        private IRepositoryBase<Domain.WebsiteCredentials> credentialsRepository;
        private IMapper mapper;
        private IEnumerable<IValidationStrategy> validations = new List<IValidationStrategy>
        {
            new NotFoundValidation("Website not found"),
            new DeletedValidation("Can't update a deleted website")
        };

        public UpdateWebsiteCommand(
            IWebsiteRepository repository,
            IRepositoryBase<Domain.WebsiteCredentials> credentialsRepository,
            IMapper mapper)
        {
            this.repository = repository;
            this.credentialsRepository = credentialsRepository;
            this.mapper = mapper;
        }

        public async Task<ServerResponse<ServerResponseTypeEnum, object>> Handle(int id, WebsiteUpdateDto dto)
        {
            var website = await repository.GetByIdAsync(id);
            foreach (var validation in validations)
            {
                var validationResult = validation.Validate(website);
                if (validationResult != null)
                {
                    return new ServerResponse<ServerResponseTypeEnum, object>(validationResult.Response, null, validationResult.Message);
                }
            }

            dto.Id = id;
            dto.WebsiteCredentialsId = website.WebsiteCredentialsId;

            website = mapper.Map<Website>(dto);
            await repository.UpdateAsync(website);

            return new ServerResponse<ServerResponseTypeEnum, object>(ServerResponseTypeEnum.NoContent, null);
        }
    }
}
