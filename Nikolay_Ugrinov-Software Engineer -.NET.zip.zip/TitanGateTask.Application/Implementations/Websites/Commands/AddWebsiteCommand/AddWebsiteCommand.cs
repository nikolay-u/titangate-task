﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Contracts.Websites.Commands;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Validation;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Implementations.Websites.Commands.AddWebsiteCommand
{
    public class AddWebsiteCommand : IAddWebsiteCommand
    {
        private IWebsiteRepository repository;
        private IRepositoryBase<Domain.WebsiteCredentials> credentialsRepository;
        private IMapper mapper;

        public AddWebsiteCommand(
            IWebsiteRepository repository,
            IRepositoryBase<Domain.WebsiteCredentials> credentialsRepository,
            IMapper mapper)
        {
            this.repository = repository;
            this.credentialsRepository = credentialsRepository;
            this.mapper = mapper;
        }

        public async Task<ServerResponse<ServerResponseTypeEnum, int>> Handle(WebsiteCreateDto dto)
        {
            var website = mapper.Map<Website>(dto);
            
            var websiteCredentials = mapper.Map<Domain.WebsiteCredentials>(dto);
            await credentialsRepository.AddAsync(websiteCredentials);
            website.WebsiteCredentialsId = websiteCredentials.Id;
           
            await repository.AddAsync(website);
            
            return new ServerResponse<ServerResponseTypeEnum, int>(ServerResponseTypeEnum.Created, website.Id);
        }
    }
}
