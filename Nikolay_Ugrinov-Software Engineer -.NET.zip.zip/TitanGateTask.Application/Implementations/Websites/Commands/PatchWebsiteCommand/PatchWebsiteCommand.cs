﻿using AutoMapper;
using Microsoft.AspNetCore.JsonPatch;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Contracts.Websites.Commands;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Validation;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Implementations.Websites.Commands.PatchWebsiteCommand
{
    public class PatchWebsiteCommand : IPatchWebsiteCommand
    {
        private IWebsiteRepository repository;
        private IMapper mapper;
        private IEnumerable<IValidationStrategy> validations = new List<IValidationStrategy>
        {
            new NotFoundValidation("Website not found"),
            new DeletedValidation("Can't update a deleted website")
        };

        public PatchWebsiteCommand(
            IWebsiteRepository repository,
            IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<ServerResponse<ServerResponseTypeEnum, object>> Handle(int id, JsonPatchDocument<WebsiteUpdateDto> dto)
        {
            var website = await repository.GetByIdAsync(id);
            foreach (var validation in validations)
            {
                var validationResult = validation.Validate(website);
                if (validationResult != null)
                {
                    return new ServerResponse<ServerResponseTypeEnum, object>(validationResult.Response, null, validationResult.Message);
                }
            }

            var updateWebsite = mapper.Map<WebsiteUpdateDto>(website);
            dto.ApplyTo(updateWebsite);
            mapper.Map(updateWebsite, website);

            await repository.UpdateAsync(website);

            return new ServerResponse<ServerResponseTypeEnum, object>(ServerResponseTypeEnum.NoContent, null);
        }
    }
}
