﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Contracts.Websites.Commands;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Validation;

namespace TitanGateTask.Application.Implementations.Websites.Commands.DeleteWebsiteCommand
{
    public class DeleteWebsiteCommand : IDeleteWebsiteCommand
    {
        private IWebsiteRepository repository;
        private IEnumerable<IValidationStrategy> validations = new List<IValidationStrategy>
        {
            new NotFoundValidation("Website not found"),
            new DeletedValidation("Can't delete a deleted website")
        };

        public DeleteWebsiteCommand(IWebsiteRepository repository)
        {
            this.repository = repository;
        }

        public async Task<ServerResponse<ServerResponseTypeEnum, object>> Handle(int id)
        {
            var website = await repository.GetByIdAsync(id);
            foreach (var validation in validations)
            {
                var validationResult = validation.Validate(website);
                if (validationResult != null)
                {
                    return new ServerResponse<ServerResponseTypeEnum, object>(validationResult.Response, null, validationResult.Message);
                }
            }

            website.IsDeleted = true;
            await repository.UpdateAsync(website);

            return new ServerResponse<ServerResponseTypeEnum, object>(ServerResponseTypeEnum.NoContent, null);
        }
    }
}
