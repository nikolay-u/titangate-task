﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Contracts.Websites.Queries;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Enums;
using TitanGateTask.Application.Validation;

namespace TitanGateTask.Application.Implementations.Websites.Queries.GetSingleWebsiteQuery
{
    public class GetSingleWebsiteQuery : IGetSingleWebsiteQuery
    {
        private IWebsiteRepository repository;
        private IMapper mapper;
        private IEnumerable<IValidationStrategy> validations = new List<IValidationStrategy>
        {
            new NotFoundValidation("Website not found"),
            new DeletedValidation("Website has been deleted")
        };

        public GetSingleWebsiteQuery(IWebsiteRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<ServerResponse<ServerResponseTypeEnum, WebsiteSingleDto>> Handle(int id)
        {
            var website = await repository.GetByIdAsync(id);
            foreach(var validation in validations)
            {
                var validationResult = validation.Validate(website);
                if (validationResult != null)
                {
                    return new ServerResponse<ServerResponseTypeEnum, WebsiteSingleDto>(validationResult.Response, null, validationResult.Message); 
                }
            }

            var dto = mapper.Map<WebsiteSingleDto>(website);
            return new ServerResponse<ServerResponseTypeEnum, WebsiteSingleDto>(ServerResponseTypeEnum.OK, dto);
        }
    }
}
