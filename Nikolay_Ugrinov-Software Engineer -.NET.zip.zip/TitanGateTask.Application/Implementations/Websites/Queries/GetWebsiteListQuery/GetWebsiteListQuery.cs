﻿using AutoMapper;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Contracts.Websites.Queries;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.RequestFeatures;

namespace TitanGateTask.Application.Implementations.Websites.Queries.GetWebsiteListQuery
{
    public class GetWebsiteListQuery : IGetWebsiteListQuery
    {
        private IWebsiteRepository repository;
        private IMapper mapper;
        public GetWebsiteListQuery(IWebsiteRepository repository, IMapper mapper)
        {
            this.repository = repository;
            this.mapper = mapper;
        }

        public async Task<PagedList<WebsiteListItemDto>> Handle(WebsiteRequestParameters parameters)
        {
            var list = await this.repository.PagedList(parameters, false);
            var metadata = list.MetaData;
            var pagedList = new PagedList<WebsiteListItemDto>(mapper.Map<List<WebsiteListItemDto>>(list), list.MetaData.TotalCount, list.MetaData.CurrentPage, list.MetaData.PageSize);
            return pagedList;
        }
    }
}
