﻿using AutoMapper;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using TitanGateTask.Application.Contracts.WebsiteCredentials;
using TitanGateTask.Application.Contracts.Websites.Commands;
using TitanGateTask.Application.Contracts.Websites.Queries;
using TitanGateTask.Application.Implementations.WebsiteCredentials.Commands.UpdateWebsiteCredentialsCommand;
using TitanGateTask.Application.Implementations.Websites.Commands.AddWebsiteCommand;
using TitanGateTask.Application.Implementations.Websites.Commands.DeleteWebsiteCommand;
using TitanGateTask.Application.Implementations.Websites.Commands.PatchWebsiteCommand;
using TitanGateTask.Application.Implementations.Websites.Commands.UpdateWebsiteCommand;
using TitanGateTask.Application.Implementations.Websites.Queries.GetSingleWebsiteQuery;
using TitanGateTask.Application.Implementations.Websites.Queries.GetWebsiteListQuery;
using TitanGateTask.Application.Mappings;

namespace TitanGateTask.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddApplication(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IGetWebsiteListQuery,GetWebsiteListQuery>();
            services.AddScoped<IGetSingleWebsiteQuery, GetSingleWebsiteQuery>();
            services.AddScoped<IAddWebsiteCommand, AddWebsiteCommand>();
            services.AddScoped<IUpdateWebsiteCommand, UpdateWebsiteCommand>();
            services.AddScoped<IPatchWebsiteCommand, PatchWebsiteCommand>();
            services.AddScoped<IDeleteWebsiteCommand, DeleteWebsiteCommand>();
            services.AddScoped<IUpdateWebsiteCredentialsCommand, UpdateWebsiteCredentialsCommand>();

            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new WebsiteCredentialsProfile());
                mc.AddProfile(new WebsiteProfile());
            });

            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
            return services;
        }
    }
}
