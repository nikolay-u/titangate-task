﻿using System;
using System.Collections.Generic;
using System.Text;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.Enums;
using TitanGateTask.Domain.Contracts;

namespace TitanGateTask.Application.Validation
{
    public class NotFoundValidation : IValidationStrategy
    {
        private string message = "Entity has not been found";
        public NotFoundValidation()
        {

        }

        public NotFoundValidation(string message)
        {
            this.message = message;
        }

        public ServerResponse<ServerResponseTypeEnum, IEntity> Validate(IEntity entity)
        {
            if (entity == null)
            {
                return new ServerResponse<ServerResponseTypeEnum, IEntity>(ServerResponseTypeEnum.NotFound, entity, message);
            }

            return null;
        }
    }
}
