﻿using System;
using System.Collections.Generic;
using System.Text;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.Enums;
using TitanGateTask.Domain.Contracts;

namespace TitanGateTask.Application.Validation
{
    public class DeletedValidation : IValidationStrategy
    {
        private string message = "Entity has been deleted";
        public DeletedValidation()
        {

        }

        public DeletedValidation(string message)
        {
            this.message = message;
        }

        public ServerResponse<ServerResponseTypeEnum, IEntity> Validate(IEntity entity)
        {
            if (entity.IsDeleted)
            {
                return new ServerResponse<ServerResponseTypeEnum, IEntity>(ServerResponseTypeEnum.Deleted, entity, message);
            }

            return null;
        }
    }
}
