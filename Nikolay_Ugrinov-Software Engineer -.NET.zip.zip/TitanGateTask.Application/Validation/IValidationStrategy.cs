﻿using System;
using System.Collections.Generic;
using System.Text;
using TitanGateTask.Application.DataTransferObjects;
using TitanGateTask.Application.Enums;
using TitanGateTask.Domain.Contracts;

namespace TitanGateTask.Application.Validation
{
    public interface IValidationStrategy
    {
        ServerResponse<ServerResponseTypeEnum, IEntity> Validate(IEntity entity);
    }
}
