﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Infrastructure.Contracts;
using TitanGateTask.Persistence.Static.Implementations.Repositories;
using TitanGateTask.Persistence.Static.Logging;

namespace TitanGateTask.Persistence.Static
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddStaticInfrastructure(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddScoped<IWebsiteRepository, WebsiteRepository>();
            services.AddScoped(typeof(IRepositoryBase<>), typeof(RepositoryBase<>));
            services.AddScoped<ILoggerManager, LoggerManager>();

            return services;
        }
    }
}
