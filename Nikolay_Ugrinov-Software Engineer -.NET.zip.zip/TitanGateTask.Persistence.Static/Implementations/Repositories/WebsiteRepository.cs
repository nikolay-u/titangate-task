﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TitanGateTask.Application.Contracts.Repositories;
using TitanGateTask.Application.Implementations.Websites.Queries.GetWebsiteListQuery;
using TitanGateTask.Application.RequestFeatures;
using TitanGateTask.Domain;

namespace TitanGateTask.Persistence.Static.Implementations.Repositories
{
    public class WebsiteRepository : IWebsiteRepository
    {
        public Task<Website> AddAsync(Website entity)
        {
            throw new NotImplementedException();
        }

        public Task DeleteAsync(Website entity)
        {
            throw new NotImplementedException();
        }

        public async Task<Website> GetByIdAsync(int id)
        {
            return list.FirstOrDefault(website => website.Id == id);
        }

        public IQueryable<Website> ListAllAsync()
        {
            throw new NotImplementedException();
        }

        public async Task<PagedList<Website>> PagedList(WebsiteRequestParameters parameters, bool trackChanges)
        {
            return PagedList<Website>.ToPagedList(list, 1, 2); 
        }

        public Task UpdateAsync(Website entity)
        {
            throw new NotImplementedException();
        }

        private static List<Website> list = new List<Website>
            {
                new Website
                {
                    Id = 1,
                    Name = "Static Google",
                    Url = "http://google.com",
                    Category = new Category
                    {
                        Id=1,
                        Name="STATIC Search"
                    },
                    HomepageSnapshot="asdasd",
                    WebsiteCredentials = new WebsiteCredentials
                    {
                        Email="asd",
                        Password = "sad2"
                    }
                },

                new Website
                {
                    Id = 2,
                    Name = "Static Youtube",
                    Url = "http://youtube.com",
                    Category = new Category
                    {
                        Id=1,
                        Name="STATIC Social Media"
                    },
                    HomepageSnapshot="asdasd",
                    WebsiteCredentials = new WebsiteCredentials
                    {
                        Email="11asd",
                        Password = "22sad2"
                    }
                }
            };
    }
}
