﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Application.Models.DataTransferObjects.WebsiteCredentials;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Mappings
{
    public class WebsiteCredentialsProfile : Profile
    {
        public WebsiteCredentialsProfile()
        {
            CreateMap<WebsiteCredentials, WebsiteCredentialsDto>()
                .ReverseMap();

            CreateMap<WebsiteCredentials, WebsiteCreateDto>()
              .ReverseMap();

            CreateMap<WebsiteCredentialsUpdateDto, WebsiteCredentials>()
                .ForMember(x => x.Password, o => o.MapFrom(src => src.NewPassword))
              .ReverseMap();
        }
    }
}
