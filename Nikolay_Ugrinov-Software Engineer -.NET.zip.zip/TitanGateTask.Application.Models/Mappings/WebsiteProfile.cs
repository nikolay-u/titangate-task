﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using TitanGateTask.Application.DataTransferObjects.Websites;
using TitanGateTask.Domain;

namespace TitanGateTask.Application.Mappings
{
    public class WebsiteProfile : Profile
    {
        public WebsiteProfile()
        {
            CreateMap<Website, WebsiteListItemDto>()
                .ForMember(x => x.Category, o => o.MapFrom(src => src.Category.Name))
                .ForMember(x => x.Login, o => o.MapFrom(src => src.WebsiteCredentials))
                .ReverseMap();

            CreateMap<Website, WebsiteSingleDto>()
               .ForMember(x => x.Category, o => o.MapFrom(src => src.Category.Name))
               .ForMember(x => x.Login, o => o.MapFrom(src => src.WebsiteCredentials))
               .ReverseMap();

            CreateMap<Website, WebsiteCreateDto>()
              .ReverseMap();

            CreateMap<Website, WebsiteUpdateDto>()
             .ReverseMap();
        }
    }
}
