﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TitanGateTask.Application.DataTransferObjects
{
    public class ServerResponse<ServerResponseTypeEnum, T>
    {
        public ServerResponseTypeEnum Response { get; private set; }

        public T Data { get; private set; }

        public string Message { get; set; }

        public ServerResponse(ServerResponseTypeEnum response, T data)
        {
            Response = response;
            Data = data;
        }

        public ServerResponse(ServerResponseTypeEnum response, T data, string message)
        {
            Response = response;
            Data = data;
            Message = message;
        }
    }
}
