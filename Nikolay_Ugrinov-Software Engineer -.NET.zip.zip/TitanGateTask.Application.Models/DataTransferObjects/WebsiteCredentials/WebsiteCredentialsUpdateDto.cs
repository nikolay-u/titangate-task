﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TitanGateTask.Application.Models.DataTransferObjects.WebsiteCredentials
{
    public class WebsiteCredentialsUpdateDto
    {
        [Required]
        [MinLength(5)]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [Required]
        [MinLength(5)]
        [DataType(DataType.Password)]
        [Compare(nameof(NewPassword), ErrorMessage = "Passwords don't match")]
        public string ConfirmNewPassword { get; set; }

        [Required]
        [MinLength(5)]
        [EmailAddress]
        public string Email { get; set; }
    }
}
