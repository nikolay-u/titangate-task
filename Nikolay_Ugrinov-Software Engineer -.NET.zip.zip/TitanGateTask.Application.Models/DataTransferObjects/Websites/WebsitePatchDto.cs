﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TitanGateTask.Application.DataTransferObjects.Websites
{
    public class WebsitePatchDto
    {

    }
}
