﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TitanGateTask.Application.DataTransferObjects.Websites
{
    public class WebsiteUpdateDto
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public string Url { get; set; }

        [Required]
        public string HomepageSnapshot { get; set; }

        [Required]
        public int CategoryId { get; set; }

        public int WebsiteCredentialsId { get; set; }
    }
}
