﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TitanGateTask.Application.DataTransferObjects.Websites
{
    public class WebsiteCreateDto
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public string Url { get; set; }

        [Required]
        public string HomepageSnapshot { get; set; }

        [Required]
        public int CategoryId { get; set; }

        [Required]
        [MinLength(5)]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [MinLength(5)]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [MinLength(5)]
        [DataType(DataType.Password)]
        [Compare(nameof(Password), ErrorMessage = "Passwords don't match")]
        public string ConfirmPassword { get; set; }
    }
}
