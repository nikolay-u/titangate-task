﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TitanGateTask.Application.DataTransferObjects.Websites
{
    public class WebsiteCredentialsDto
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }
}
