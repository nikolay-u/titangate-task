﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TitanGateTask.Application.Enums
{
    public enum ServerResponseTypeEnum
    {
        OK,
        Created,
        NoContent,
        NotFound,
        Deleted,
        BadRequest
    }
}
