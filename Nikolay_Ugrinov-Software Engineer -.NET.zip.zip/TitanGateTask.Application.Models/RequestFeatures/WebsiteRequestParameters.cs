﻿using System;
using System.Collections.Generic;
using System.Text;
using TitanGateTask.Application.RequestFeatures;

namespace TitanGateTask.Application.RequestFeatures
{
    public class WebsiteRequestParameters: RequestParameters
    {
        public string SearchTerm { get; set; }

        public int? CategoryId { get; set; }

        public bool IsDeleted { get; set; }
    }
}
